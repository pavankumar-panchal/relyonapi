<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="23%" valign="top" style="font-weight:bold"><table width="100%" border="0" cellspacing="0" cellpadding="0" id="mainwrap">
        <tr>
          <td align="left" valign="top">You are not Authorised to view this page. </td>
        </tr>
    </table></td>
  </tr>
</table>

