<?
	//Define the connection parameters - MySQL
	if($_SERVER['HTTP_HOST'] == "bhavesh" || $_SERVER['HTTP_HOST'] == "192.168.2.132")
	{
			$dbhost = "localhost"; $dbuser = "root";	$dbpwd = "";	$dbname = "userlogin2";
	}
	else
	{
			$dbhost = "localhost"; $dbuser = "relyonso_newuser";	$dbpwd = "newera@123$";$dbname = "relyonso_userlogin2";
	}

?>