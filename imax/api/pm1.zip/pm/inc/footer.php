
	  <div id="footer">
	  <table width="100%" border="0" cellpadding="2" cellspacing="0" class="foottext">
        
        <tr>
          <td><div align="right" id="copyright">&copy; <?php print (date("Y")); ?> Relyon Softech Ltd. All rights reserved Powered by <a target="_blank" href="http://www.relyonsoft.com">Relyon Softech Limited
</a></div></td>
        </tr>
      </table>
	  </div>	