<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title></title>

</head>



<body>

<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" >

  <tr>

    <td colspan="3" ><table width="100%" border="0" cellspacing="0" cellpadding="1">

      <tr>

        <td  width="73%" style="text-align:left"><strong>Relyon Softech Ltd</strong><br/>

              <font color="#008000"><strong>The Ultimate Arena for Software Products.</strong></font><br/>

          No. 73, Shreelekha Complex, WOC Road,Bangalore :560 086<br/>

          <strong>Phone</strong>: 080-23002100 | <strong>Telefax</strong>: 080-23193552<br/>

          <strong>Email</strong>: info@relyonsoft.com |  www.relyonsoft.com</td>



        <td width="27%"   style="text-align:right;" valign="middle"><img src="http://relyonsoft.com/images/relyon-logo.jpg" width="120" height="40" border="0" valign="middle" /></td>



      </tr>

    </table></td>

  </tr>

  <tr>

    <td colspan="3" style="text-align:center"><font color="#FF3300"><strong>PAYMENT RECEIPT</strong></font></td>

  </tr>

  <tr bgcolor="#CCCCCC">

    <td width="60%" colspan="2" ><div align="left"><strong>Customer Details</strong></div></td>

    <td width="40%"><div align="left"><strong>Receipt Details</strong></div></td>

  </tr>

  <tr>

    <td width="60%" colspan="2" style="text-align:left"><strong>Customer ID:</strong> ##CUSTOMERID##</td>

    <td style="text-align:left" width="40%"><strong>Date:</strong> ##RECEIPTDATE##</td>

  </tr>

  <tr>

    <td width="60%" colspan="2" style="text-align:left"><strong>##BUSINESSNAME##</strong></td>

    <td style="text-align:left" width="40%"><strong>Receipt No:</strong> <span style="text-align:right">##SLNO##</span></td>

  </tr>

  <tr>

    <td width="60%" colspan="2" style="text-align:left">##ADDRESS##</td>

    <td style="text-align:left" width="40%"><strong>Marketing Exe: </strong>##RELYONREP##</td>

  </tr>

 

 

 

  <tr>

    <td colspan="3" style="border:none;" height="50px"><table width="100%" border="0" cellspacing="0" cellpadding="0">

     

      <tr>

        <td style="font-size:34px"><div align="justify">

          <p>Received with thanks from <strong>##BUSINESSNAME##</strong> for<img src="../images/relyon-rupee-small.jpg" alt="" width="8" height="8" border="0" align="absmiddle" /> ##AMOUNT## against Invoice number ##INVOICENO## </p>

          <p><strong>Amount in words</strong>: Rupees ##AMOUNTINWORDS## only </p>

         

          </div></td>

      </tr>

      <tr>

        <td style="font-size:34px"><div align="justify"><strong>Mode of Payment:</strong> ##MODE##</div></td>

      </tr>

      <tr>

        <td style="font-size:34px"><div align="justify"><strong>Payment details:</strong>##REMARKS##</div></td>

      </tr>

       <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

  <tr>

    <td colspan="2" style="text-align:left" width="60%" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">

     

      

    </table></td>

    <td style="text-align:left" width="40%"><div align="center"><font color="#FF0000">For <strong>RELYON SOFTECH LTD</strong></font> <br />

            <br />

            

      ##GENERATEDBY## </div></td>

  </tr>

</table>

</body>

</html>

