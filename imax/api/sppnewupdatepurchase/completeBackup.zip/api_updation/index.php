<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body>
<a href="api.php?cusid=26103&productcode=353">Buynow</a>
</body>
</html>