<?
		
		
	$dbhost = "66.228.55.243"; $dbuser = "manju";	$dbpwd = "cd4017";	$dbname = "relyon_imax";
	
		

?>
