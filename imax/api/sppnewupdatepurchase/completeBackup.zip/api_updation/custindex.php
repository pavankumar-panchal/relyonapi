<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body>


<form action="custindex2.php" method="post">
c<input type="text" name="Qa1iio9" id ="Qa1iio9"><br/>
p<input type="text" name="AsWrIo" id ="AsWrIo"><br/>
<input type="submit">


</form>
</body>
</html>
<!--33364-->
<!--26103-->