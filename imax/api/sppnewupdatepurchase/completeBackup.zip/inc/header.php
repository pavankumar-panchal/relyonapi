<table width="75%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr>
          <td><img src="images/relyon-logo.jpg" alt="Customer Payment" />
            <div id="givepaymentoptions" style="text-align:center;float: right; margin-top: 5%;"></div>
         </td>
       </tr>
</table>            