<table width="78%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="border:1px solid #d0c3c5; background-color:#FFFFFF"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="5" colspan="2"></td>
        </tr>
        <tr>
          <td width="100%" colspan="2" style="text-align:center">&copy; Relyon Softech Limited | <span style="text-decoration:none"><a href="http://www.relyonsoft.com" class="Link" target="_blank"> www.relyonsoft.com</a></span></td>
        </tr>
        <tr>
          <td height="5" colspan="2"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
</table>
