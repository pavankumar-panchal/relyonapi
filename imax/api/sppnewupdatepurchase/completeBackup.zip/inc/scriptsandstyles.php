<?
	if(file_exists("../css/style.css")) echo('<LINK href="../css/style.css" rel=stylesheet>');
	elseif(file_exists("../../css/style.css")) echo('<LINK href="../../css/style.css" rel=stylesheet>');
	elseif(file_exists("../../../css/style.css")) echo('<LINK href="../../../css/style.css" rel=stylesheet>');
	elseif(file_exists("./css/style.css")) echo('<LINK href="./css/style.css" rel=stylesheet>');
	
	if(file_exists("../functions/jquery-1.4.2.min.js")) echo('<SCRIPT src="../functions/jquery-1.4.2.min.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../functions/jquery-1.4.2.min.js")) echo('<SCRIPT src="../../functions/jquery-1.4.2.min.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../../functions/jquery-1.4.2.min.js")) echo('<SCRIPT src="../../../functions/jquery-1.4.2.min.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("./functions/jquery-1.4.2.min.js")) echo('<SCRIPT src="./functions/jquery-1.4.2.min.js" type=text/javascript></SCRIPT>');
	
	if(file_exists("../functions/jquery-xtra.js")) echo('<SCRIPT src="../functions/jquery-xtra.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../functions/jquery-xtra.js")) echo('<SCRIPT src="../../functions/jquery-xtra.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../../functions/jquery-xtra.js")) echo('<SCRIPT src="../../../functions/jquery-xtra.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("./functions/jquery-xtra.js")) echo('<SCRIPT src="./functions/jquery-xtra.js" type=text/javascript></SCRIPT>');
	
	if(file_exists("../functions/pnginner.js")) echo('<SCRIPT src="../functions/pnginner.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../functions/pnginner.js")) echo('<SCRIPT src="../../functions/pnginner.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../../functions/pnginner.js")) echo('<SCRIPT src="../../../functions/pnginner.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("./functions/pnginner.js")) echo('<SCRIPT src="./functions/pnginner.js" type=text/javascript></SCRIPT>');


	if(file_exists("../functions/cookies.js")) echo('<SCRIPT src="../functions/cookies.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../functions/cookies.js")) echo('<SCRIPT src="../../functions/cookies.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../../functions/cookies.js")) echo('<SCRIPT src="../../../functions/cookies.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("./functions/cookies.js")) echo('<SCRIPT src="./functions/cookies.js" type=text/javascript></SCRIPT>');

	if(file_exists("../functions/javascript.js")) echo('<SCRIPT src="../functions/javascript.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../functions/javascript.js")) echo('<SCRIPT src="../../functions/javascript.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("../../../functions/javascript.js")) echo('<SCRIPT src="../../../functions/javascript.js" type=text/javascript></SCRIPT>');
	elseif(file_exists("./functions/javascript.js")) echo('<SCRIPT src="./functions/javascript.js" type=text/javascript></SCRIPT>');
	
?>
