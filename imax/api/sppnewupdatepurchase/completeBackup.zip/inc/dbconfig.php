<?
		
	//$dbhost = "localhost"; $dbuser = "imaxtest";    $dbpwd = "RelyonImax@12#";      $dbname = "imaxtest";
        //$dbhost = "66.228.55.243"; $dbuser = "manju";	$dbpwd = "cd4017"; $dbname = "relyon_imax";

         $dbhost = "66.228.55.243"; $dbuser = "manju";	$dbpwd = "cd4017";	$dbname = "relyon_imax";

	//$pm_dbhost = "66.228.55.243"; $pm_dbuser = "manju"; $pm_dbpwd ="cd4017"; $pm_dbname = "relyon_lms";


?>