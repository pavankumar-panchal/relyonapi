<?php
include "functions/phpfunctions.php";

$a= encodevalue($_REQUEST["Qa1iio9"]);
$b= encodevalue($_REQUEST["AsWrIo"]);

header("location: index.php?Qa1iio9=".$a."&AsWrIo=".$b);

?>
