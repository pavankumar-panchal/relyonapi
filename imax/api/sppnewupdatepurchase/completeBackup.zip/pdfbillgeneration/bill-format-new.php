<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" type="text/css" href="global.css">

</head>



<body>

<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" >

  <tr>

    <td colspan="3" ><table width="100%" border="0" cellspacing="0" cellpadding="1">

  <tr>

    <td  width="73%" style="text-align:left"><strong>Relyon Softech Ltd</strong><br/><font color="#008000"><strong>The Ultimate Arena for Software Products.</strong></font><br/>      

      No. 73, Shreelekha Complex, WOC Road,Bangalore :560 086<br/><strong>Phone</strong>: 080-23002100 | <strong>Fax</strong>: 080-23193552<br/><strong>Email</strong>: info@relyonsoft.com |  www.relyonsoft.com</td>

    <td width="27%"   style="text-align:right;" valign="middle"><img src="http://www.relyonsoft.com/images/relyon-logo.jpg" width="120" height="40" border="0" valign="middle" /></td>

  </tr>

</table></td>

  </tr>

  <tr>

    <td colspan="3" style="text-align:center"><font color="#FF3300"><strong>##INVOICEHEADING##</strong></font></td>

  </tr>

   <tr bgcolor="#CCCCCC">

     <td width="60%" colspan="2" ><div align="left"><strong>Customer Details</strong></div></td>

     <td width="40%"><div align="left"><strong>Invoice Details</strong></div></td>

  </tr> 

   <tr>

     <td width="60%" colspan="2" style="text-align:left"><strong>Customer ID:</strong> ##CUSTOMERID##</td>

     <td style="text-align:left" width="40%"><strong>Date:</strong> ##BILLDATE##</td>

  </tr> 

   <tr>

     <td width="60%" colspan="2" style="text-align:left"><strong>##BUSINESSNAME##</strong></td>

     <td style="text-align:left" width="40%"><strong>No:</strong> <span style="text-align:right"><strong>##BILLNO##</strong></span><span style="text-align:right; font-size:16px"><font color="##color##"> &nbsp;&nbsp; ##STATUS## </font></span></td>

  </tr> 

   <tr>

     <td width="60%" colspan="2" style="text-align:left">##ADDRESS##</td>

     <td style="text-align:left" width="40%"><strong>Marketing Exe: </strong>##RELYONREP##&nbsp;<br/><font color="#666666"; style="font-size:16px" >##DEALERDETAILS##</font></td>

  </tr> 

   <tr>

     <td width="60%" colspan="2" style="text-align:left"><strong>Contact Person:</strong> ##CONTACTPERSON##</td>

     <td style="text-align:left" width="40%"><strong>Service Tax No:</strong> AABCR7796NST001</td>

  </tr>  <tr>

     <td width="60%" colspan="2" style="text-align:left"><strong>Email:</strong> ##EMAILID##</td>

     <td style="text-align:left" width="40%"><strong>Region: </strong> ##REGION## / ##BRANCH##</td>

  </tr> 

   <tr>

     <td style="text-align:left" width="30%"><strong>Phone:</strong> ##STDCODE####PHONE##</td>

     <td style="text-align:left" width="30%"><strong>Cell:</strong> ##CELL##</td>

     <td style="text-align:left" width="40%"><strong>Company's PAN:</strong>       AABCR7796N</td>

  </tr> 

   <tr>

     <td width="60%" colspan="2" style="text-align:left"><strong>Type of Customer: </strong>##CUSTOMERTYPE##</td>

     <td style="text-align:left" width="40%"><strong>Company's VAT TIN:</strong> 29730052233</td>

  </tr> 

   <tr>

     <td colspan="2" style="text-align:left" width="60%"><strong>Category of Customer: </strong>##CUSTOMERCATEGORY##</td>

     <td style="text-align:left" width="40%"><strong>CST No:</strong> 71684955 &nbsp; <strong>w.e.f. :</strong> 16/1/2001<br /></td>

  </tr> 

   <tr>

     <td colspan="2" style="text-align:left" width="60%"><strong>PO Date: </strong>##PODATE##</td>

     <td style="text-align:left" width="40%"><strong>PO Reference:</strong> ##POREFERENCE##<br /></td>

  </tr> 

  <tr>

    <td colspan="3" style="border:none;">##TABLE##</td>

  </tr>

   <tr>

     <td colspan="2" style="text-align:left" width="60%" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">

  <tr>

    <td><div align="left"><strong>Invoice Remarks: </strong>##INVREMARKS##</div></td>

  </tr>

  <tr>

    <td><div align="left"><strong> Payment Remarks: </strong>##PAYREMARKS##</div></td>

  </tr>

</table>

</td>

     <td style="text-align:left" width="40%"><div align="center"><font color="#FF0000">For <strong>RELYON SOFTECH LTD</strong></font> <br />

           <br />

           <br />

       ##GENERATEDBY## </div>

    </td>

  </tr> 

     <tr>

    <td colspan="3"><div align="center"><font style="font-size:20px">      This is a computer generated invoice. Hence do not require signature. | For Support on Registration / Installation / Any other queries, please contact 1860-425-5570.</font>

    </div></td>

  </tr>

    </table>

</body>

</html>

