<?php

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Test Invoice</title>
</head>

<body>
<form action="complete_citrus.php" method="post">
  <input type="text" name="TxRefNo" id="TxRefNo" value="">
  <input type="text" name="TxId" id="TxId" value="699">
  <input type="text" name="TxMsg" id="TxMsg" value="">
  <input type="text" name="pgRespCode" id="pgRespCode" value="0">
  <input type="text" name="amount" id="amount" value="">
  <input type="text" name="authIdCode" id="authIdCode" value="">
  <input type="text" name="issuerRefNo" id="issuerRefNo" value="">
  <input type="text" name="firstName" id="firstName" value="bhumika">
  <input type="text" name="lastName" id="lastName" value="patel">
  <input type="text" name="email" id="email" value="bhumika.p@relyonsoft.com">
  <input type="text" name="addressStreet1" id="addressStreet1" value="#3,4, KHAN BLDG, N.B.T. ROAD. NEAR DOCKYARD RLY STN">
  <input type="text" name="addressStreet2" id="addressStreet2" value="">
  <input type="text" name="addressCity" id="addressCity" value="MUMBAI">
  <input type="text" name="addressState" id="addressState" value="">
  <input type="text" name="addressCountry" id="addressCountry" value="India">
  <input type="text" name="addressZip" id="addressZip" value="400010">
  <input type="text" name="mandatoryErrorMsg" id="mandatoryErrorMsg" value="">
  <input type="text" name="successTxn" id="successTxn" value="">
  <input type="text" name="mobileNo" id="mobileNo" value="">
  <input type="submit" name="submit" value="Submit">
</form>
</body>
</html>