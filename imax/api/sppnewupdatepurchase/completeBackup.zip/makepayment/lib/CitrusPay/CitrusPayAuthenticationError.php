<?php

class CitrusPay_AuthenticationError extends CitrusPay_Error
{
}
